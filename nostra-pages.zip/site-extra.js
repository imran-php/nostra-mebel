(() => {
  const groupOf = item => item.projectGroup || (/коммер|офис|кафе|ресторан|магазин/i.test(item.projectType || '') ? 'commercial' : 'residential');
  const dialog = document.createElement('dialog'); dialog.className = 'project-gallery';
  dialog.innerHTML = '<button class="gallery-close" aria-label="Закрыть проекты">×</button><h2></h2><div class="project-gallery-grid"></div>';
  document.body.append(dialog);
  dialog.querySelector('.gallery-close').onclick = () => dialog.close();
  dialog.addEventListener('click', e => { if(e.target === dialog) dialog.close(); });
  document.addEventListener('click', e => {
    if (e.target.closest('.editor-pencil')) return;
    const button = e.target.closest('[data-gallery-group]'); if (!button) return;
    e.preventDefault();
    const data = window.NostraSite.getData(), group = button.dataset.galleryGroup;
    const title = data.settings.texts?.[group === 'commercial' ? 'directionCommercial' : 'directionResidential'] || (group === 'commercial' ? 'Коммерция' : 'Жилые помещения');
    dialog.querySelector('h2').textContent = title;
    const list = dialog.querySelector('.project-gallery-grid'); list.replaceChildren();
    const items = data.items.filter(i => i.kind === 'project' && groupOf(i) === group);
    if (!items.length) { const p = document.createElement('p'); p.textContent = 'Скоро здесь появятся наши проекты.'; list.append(p); }
    for (const item of items) {
      const card = document.createElement('button'); card.className = 'project-gallery-card'; card.dataset.open = item.id;
      const img = document.createElement('img'); img.src = item.cover?.startsWith("s:") ? "/nostra-mebel/images/" + item.cover.slice(2) + "-800.webp" : window.NOSTRA_PUBLIC.images[item.cover]?.t || ""; img.alt = item.title;
      const label = document.createElement('h3'); label.textContent = item.title; card.append(img,label);
      card.onclick = e => { if(e.target.closest('.editor-pencil'))return; dialog.close(); };
      list.append(card);
    }
    document.dispatchEvent(new Event('nostra:render'));
    dialog.showModal();
  });
})();
