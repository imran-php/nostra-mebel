(() => {
  const data=window.NOSTRA_INITIAL;
  window.NOSTRA_SITE_KIND='facades';
  const media = id => window.NOSTRA.base + id;
  const key=window.NOSTRA_PAGE_KEY || 'home';
  const candidates=[...document.querySelectorAll('.topbar span,.logo__name,.logo__tag,main h1,main h2,main h3,main p,main .kicker,main .specs__val,.footer p,.footer__col>span,.footer__col>a[href^="tel:"],.header__phone,.contact a[href^="tel:"]')].filter(el=>!el.closest('[data-facade-item],[data-facade-category],.config,.product-more'));
  const counts={};
  candidates.forEach(el=>{const section=el.closest('.header,.topbar')?'global-header':el.closest('.footer')?'global-footer':key;const index=counts[section]||0;counts[section]=index+1;const id=section+':text:'+index;el.dataset.contentKey=id;if(Object.hasOwn(data.settings.pageContent||{},id)){el.textContent=data.settings.pageContent[id];if(el.matches('a[href^="tel:"]'))el.href='tel:+'+el.textContent.replace(/\D/g,'');}});
  [...document.querySelectorAll('main img')].filter(el=>!el.closest('[data-facade-item],[data-facade-category],.product,.product-more')).forEach((el,index)=>{const id=key+':image:'+index;el.dataset.imageKey=id;if(data.settings.pageImages?.[id]){el.src=media(data.settings.pageImages[id]);el.removeAttribute('srcset');}});
})();
